delete employee;

insert into employee (id, name, age, gender) values
(1, 'TestUser1', 40, 1),
(2, 'TestUser2', 20, 2),
(3, 'TestUser3', 30, 1)
;