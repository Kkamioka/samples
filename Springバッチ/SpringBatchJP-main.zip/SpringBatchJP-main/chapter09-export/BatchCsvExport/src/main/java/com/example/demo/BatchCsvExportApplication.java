package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BatchCsvExportApplication {

	public static void main(String[] args) {
		SpringApplication.run(BatchCsvExportApplication.class, args);
	}

}
