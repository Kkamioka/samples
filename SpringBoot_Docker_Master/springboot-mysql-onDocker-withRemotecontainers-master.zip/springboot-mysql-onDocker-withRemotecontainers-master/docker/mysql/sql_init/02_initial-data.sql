INSERT INTO sample_schema.account (email, password, user_name) VALUES
('mng@hoge', 'mngpass', 'manager'),
('user1@hoge', 'user1pass', 'MR.user1'),
('user2@hoge', 'user2pass', 'MR.user2')
;
