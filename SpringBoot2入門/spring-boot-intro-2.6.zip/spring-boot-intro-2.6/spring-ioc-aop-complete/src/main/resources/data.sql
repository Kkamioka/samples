INSERT INTO coffee(id, name)
VALUES (1, 'ブレンドコーヒー'), (2, 'ジャワコーヒー');
