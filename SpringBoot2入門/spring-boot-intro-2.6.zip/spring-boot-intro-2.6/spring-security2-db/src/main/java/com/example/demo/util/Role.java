package com.example.demo.util;

public enum Role {
    ADMIN, USER
}
