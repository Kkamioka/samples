オリジナルのGitHubリポジトリは以下となります。

https://github.com/yuichi110/docker-kvs