#!/bin/sh
echo "start nginx"
nginx -g "daemon off;"