#!/bin/sh
echo "start nginx"
exec nginx -g "daemon off;"